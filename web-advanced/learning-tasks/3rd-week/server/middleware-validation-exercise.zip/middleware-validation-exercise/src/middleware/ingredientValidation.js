export const validateIngredientId = (req, res, next) => {
    next();
};

export const validateIngredientBody = (req, res, next) => {
    next();
};