export const loggerMiddleware = (req, res, next) => {
  next();
};