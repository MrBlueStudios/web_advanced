export const rateLimitingMiddleware = (req, res, next) => {
  next();
};